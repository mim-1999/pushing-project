<?php 

require_once ('Model/model.php');

function fetchAllOrders(){
	return showAllOrder();

$orders = $data["ID"];

}
